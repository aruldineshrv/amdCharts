export class MapModel{
    statecode:string;
    districtcode:string;
}