import { Component, OnInit ,Output ,Input,EventEmitter} from '@angular/core';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4maps from '@amcharts/amcharts4/maps';
import am4geodata_usaAlbersHigh from '@amcharts/amcharts4-geodata/usaAlbersHigh';
import am4geodata_akHigh from  '@amcharts/amcharts4-geodata/region/usa/congressional/akHigh';
//import am4geodata_akLow from  '@amcharts/amcharts4-geodata/region/usa/akLow';
import am4geodata_alHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/alHigh';
import am4geodata_arHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/arHigh';
import am4geodata_azHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/azHigh';
import am4geodata_caHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/caHigh';
import am4geodata_coHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/coHigh';
import am4geodata_ctHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/ctHigh';
import am4geodata_dcHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/dcHigh';
import am4geodata_deHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/deHigh';
import am4geodata_flHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/flHigh';
import am4geodata_gaHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/gaHigh';
import am4geodata_hiHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/hiHigh';
import am4geodata_iaHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/iaHigh';
import am4geodata_idHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/idHigh';
import am4geodata_ilHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/ilHigh';
import am4geodata_inHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/inHigh';
import am4geodata_ksHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/ksHigh';
import am4geodata_kyHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/kyHigh';
import am4geodata_laHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/laHigh';
import am4geodata_maHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/maHigh';
import am4geodata_mdHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/mdHigh';
import am4geodata_meHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/meHigh';
import am4geodata_miHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/miHigh';
import am4geodata_mnHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/mnHigh';
import am4geodata_moHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/moHigh';
import am4geodata_msHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/msHigh';
import am4geodata_mtHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/mtHigh';
import am4geodata_ncHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/ncHigh';
import am4geodata_ndHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/ndHigh';
import am4geodata_neHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/neHigh';
import am4geodata_nhHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/nhHigh';
import am4geodata_njHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/njHigh';
import am4geodata_nmHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/nmHigh';
import am4geodata_nvHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/nvHigh';
import am4geodata_nyHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/nyHigh';
import am4geodata_ohHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/ohHigh';
import am4geodata_okHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/okHigh';
import am4geodata_orHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/orHigh';
import am4geodata_paHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/paHigh';
import am4geodata_riHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/riHigh';
import am4geodata_scHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/scHigh';
import am4geodata_sdHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/sdHigh';
import am4geodata_tnHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/tnHigh';
import am4geodata_txHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/txHigh';
import am4geodata_utHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/utHigh';
import am4geodata_vaHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/vaHigh';
import am4geodata_vtHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/vtHigh';
import am4geodata_waHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/waHigh';
import am4geodata_wiHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/wiHigh';
import am4geodata_wvHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/wvHigh';
import am4geodata_wyHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/wyHigh';

import {MapModel} from './mapodel';
import { Subscription,Observable } from 'rxjs';

@Component({
  selector: 'app-gpaamap',
  templateUrl: './gpaamap.component.html',
  styleUrls: ['./gpaamap.component.css']
})
export class GpaamapComponent  {
 private eventsSubscription: Subscription;
 @Input() dataFromParent: Observable<void>;
 @Output() messageEvent = new EventEmitter<MapModel>();


  mapModelObject:MapModel=new MapModel();
  mapChart: any;
  selectedStateCode = '';
  selectedDistrictCode = null;


  syncToChild($event: any){
    alert("Child ");
  }
  
  constructor() {}




  ngOnInit() {
  this.eventsSubscription = this.dataFromParent.subscribe((data) => this.syncToMap(data));
  }
  selectStates(statecode:string) {
    this.mapModelObject.statecode=statecode;
    this.mapModelObject.districtcode=null;
    this.messageEvent.emit(this.mapModelObject);
  }

  selectDistricts(districtCode:string) {
   this.mapModelObject.districtcode=districtCode;
  }

  syncToMap(data)
  {
    this.mapModelObject.statecode=data.statecode;
    this.mapModelObject.districtcode=data.districtcode;
    if(this.mapModelObject.statecode!=null && this.mapModelObject.districtcode==null)
    {
      this.selectedStateCode=this.mapModelObject.statecode;
      this.renderStateMap(true);
    }
    else if(this.mapModelObject.statecode!=null && this.mapModelObject.districtcode!=null)
    {
      this.selectedStateCode=this.mapModelObject.statecode;
      this.selectedDistrictCode=this.mapModelObject.districtcode;
      this.renderDistrictMap(true);
    }
    else if(this.mapModelObject.statecode==null && this.mapModelObject.districtcode==null)
    {
      this.resetChart();
    }
  }


  ngAfterViewInit() {
    this.renderStateMap(false);
  }
  stateDrillDown(value) {
    console.log("Selected State"+value);
    this.selectedStateCode=value;
    //this.selectedStateCode="US-DC";

    this.renderDistrictMap(false);
  }

  districtDrillDown(value) {
    this.selectedDistrictCode=value;
    this.renderDistrictMap(true);
  }

  selectState(statecode:string) {
    this.selectedStateCode=statecode;
    console.log("ccccccccccccccccccccc");
    this.renderStateMap(true);
  }

  resetChart()
  {
    this.renderStateMap(false);
  }


  renderDistrictMap(districtSelectedFlag: boolean) {
    let componentScope = this;
    //am4core.useTheme(am4themes_animated);
    var container = am4core.create('concatChart', am4core.Container);
    container.width = am4core.percent(100);
    container.height = am4core.percent(100);
    this.mapChart = container.createChild(am4maps.MapChart);
    this.mapChart.geodata = this.getDistrictMapdata(this.selectedStateCode);
    console.log("MAP GEO DATA "+JSON.stringify(this.mapChart.geodata));
    this.mapChart.projection = new am4maps.projections.Miller();
    var polygonSeries = this.mapChart.series.push(
      new am4maps.MapPolygonSeries()
    );
    polygonSeries.useGeodata = true;
    polygonSeries.mapPolygons.template.fill = am4core.color('#808080');
    var polygonTemplate = polygonSeries.mapPolygons.template;
    polygonTemplate.tooltipText = '{name}';
    polygonTemplate.fill = am4core.color('#808080');

    var hs = polygonTemplate.states.create('hover');
    hs.properties.fill = am4core.color('#FFA500');

    var hsa = polygonTemplate.states.create('click');
    hsa.properties.fill = am4core.color('#FF0000');

    var activeState = polygonTemplate.states.create('active');
    activeState.properties.fill = am4core.color('#800080');
    polygonSeries.mapPolygons.template.events.on('hit', function (ev) {
      polygonSeries.mapPolygons.each(function (polygon) {
        //console.log(polygon.uid);
        polygon.isActive = false;
      });
      ev.target.isActive = true;
      var districtCode = ev.target.dataItem.dataContext.id;
      console.log('DISTRICT  CODE' + districtCode);
      componentScope.districtDrillDown(districtCode);

    });

    let button = this.mapChart.createChild(am4core.Button);
    button.padding(5, 5, 5, 5);
    button.align = "right";
    button.marginRight = 15;
    button.events.on("hit", function() {
      componentScope.resetChart();
    });
    button.icon = new am4core.Sprite();
    button.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";

    if (districtSelectedFlag) {
      var selectedDistricts = [];
      selectedDistricts.push(componentScope.selectedDistrictCode);
      console.log('selectedDistrict::::' + selectedDistricts);
      var data = [];
      selectedDistricts.map(function (id) {
        data.push({
          id: id,
          color: '#800080',
        });
      });
      polygonTemplate.propertyFields.fill = 'color';
      polygonSeries.data = data;
    }
  }

  renderStateMap(stateSelectedFlag: boolean) {
    let componentScope = this;
    var container = am4core.create('concatChart', am4core.Container);
    container.width = am4core.percent(100);
    container.height = am4core.percent(100);
    this.mapChart = container.createChild(am4maps.MapChart);
       this.mapChart.geodata = am4geodata_usaAlbersHigh;
    this.mapChart.projection = new am4maps.projections.Miller();
    var polygonSeries = this.mapChart.series.push(
      new am4maps.MapPolygonSeries()
    );
    polygonSeries.useGeodata = true;
    polygonSeries.mapPolygons.template.fill = am4core.color('#808080');
    var polygonTemplate = polygonSeries.mapPolygons.template;
    polygonTemplate.tooltipText = '{name}';
    polygonTemplate.fill = am4core.color('#808080');

    var hs = polygonTemplate.states.create('hover');
    hs.properties.fill = am4core.color('#FFA500');

    var hsa = polygonTemplate.states.create('click');
    hsa.properties.fill = am4core.color('#FF0000');

    var activeState = polygonTemplate.states.create('active');
    activeState.properties.fill = am4core.color('#800080');
    polygonSeries.mapPolygons.template.events.on('hit', function (ev) {
      polygonSeries.mapPolygons.each(function (polygon) {
        //console.log(polygon.uid);
        polygon.isActive = false;
      });
      ev.target.isActive = true;
      var statecode = ev.target.dataItem.dataContext.id;
      console.log("Selected Code:"+statecode);
      componentScope.stateDrillDown(statecode);

    });

    if (stateSelectedFlag) {
      var selectedStates = [];
      selectedStates.push(componentScope.selectedStateCode);
      console.log('selectedStates::::' + selectedStates);
      var data = [];
      selectedStates.map(function (id) {
        data.push({
          id: id,
          color: '#800080',
        });
      });
      polygonTemplate.propertyFields.fill = 'color';
      polygonSeries.data = data;
    }
  }

  getDistrictMapdata(stateId:string)
  {


      if(stateId=='US-AK')
      {
        console.log("IN ALASKA TRIGGGERED")
        return  am4geodata_akHigh;
      }
      
      if(stateId=='US-AL')
      return  am4geodata_alHigh;
      if(stateId=='US-AR')
      return  am4geodata_arHigh;
      if(stateId=='US-AZ')
      return  am4geodata_azHigh;
      if(stateId=='US-CA')
      return  am4geodata_caHigh;
      if(stateId=='US-CO')
      return  am4geodata_coHigh;
      if(stateId=='US-CT')
      return  am4geodata_ctHigh;
      if(stateId=='US-DC')
      return  am4geodata_dcHigh;
      if(stateId=='US-DE')
      return  am4geodata_deHigh;
      if(stateId=='US-FL')
      return  am4geodata_flHigh;
      if(stateId=='US-GA')
      return  am4geodata_gaHigh;
      if(stateId=='US-HI')
      return  am4geodata_hiHigh;
      if(stateId=='US-IA')
      return  am4geodata_iaHigh;
      if(stateId=='US-ID')
      return  am4geodata_idHigh;
      if(stateId=='US-IL')
      return  am4geodata_ilHigh;
      if(stateId=='US-IN')
      return  am4geodata_inHigh;
      if(stateId=='US-KS')
      return  am4geodata_ksHigh;
      if(stateId=='US-KY')
      return  am4geodata_kyHigh;
      if(stateId=='US-LA')
      return  am4geodata_laHigh;
      if(stateId=='US-MA')
      return  am4geodata_maHigh;
      if(stateId=='US-MD')
      return  am4geodata_mdHigh;
      if(stateId=='US-ME')
      return  am4geodata_meHigh;
      if(stateId=='US-MI')
      return  am4geodata_miHigh;
      if(stateId=='US-MN')
      return  am4geodata_mnHigh;
      if(stateId=='US-MO')
      return  am4geodata_moHigh;
      if(stateId=='US-MS')
      return  am4geodata_msHigh;
      if(stateId=='US-MT')
      return  am4geodata_mtHigh;
      if(stateId=='US-NC')
      return  am4geodata_ncHigh;
      if(stateId=='US-ND')
      return  am4geodata_ndHigh;
      if(stateId=='US-NE')
      return  am4geodata_neHigh;
      if(stateId=='US-NH')
      return  am4geodata_nhHigh;
      if(stateId=='US-NJ')
      return  am4geodata_njHigh;
      if(stateId=='US-NM')
      return  am4geodata_nmHigh;
      if(stateId=='US-NV')
      return  am4geodata_nvHigh;
      if(stateId=='US-NY')
      return  am4geodata_nyHigh;
      if(stateId=='US-OH')
      return  am4geodata_ohHigh;
      if(stateId=='US-OK')
      return  am4geodata_okHigh;
      if(stateId=='US-OR')
      return  am4geodata_orHigh;
      if(stateId=='US-PA')
      return  am4geodata_paHigh;
      if(stateId=='US-RI')
      return  am4geodata_riHigh;
      if(stateId=='US-SC')
      return  am4geodata_scHigh;
      if(stateId=='US-SD')
      return  am4geodata_sdHigh;
      if(stateId=='US-TN')
      return  am4geodata_tnHigh;
      if(stateId=='US-TX')
      return  am4geodata_txHigh;
      if(stateId=='US-UT')
      return  am4geodata_utHigh;
      if(stateId=='US-VA')
      return  am4geodata_vaHigh;
      if(stateId=='US-VT')
      return  am4geodata_vtHigh;
      if(stateId=='US-WA')
      return  am4geodata_waHigh;
      if(stateId=='US-WI')
      return  am4geodata_wiHigh;
      if(stateId=='US-WV')
      return  am4geodata_wvHigh;
      if(stateId=='US-WY')
      return  am4geodata_wyHigh;
  }


}
