import { Component, OnInit ,Output ,EventEmitter} from '@angular/core';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4maps from '@amcharts/amcharts4/maps';
import am4geodata_usaAlbersHigh from '@amcharts/amcharts4-geodata/usaAlbersHigh';
import am4geodata_tnHigh from '@amcharts/amcharts4-geodata/region/usa/congressional/tnHigh';
import {MapModel} from './gpaamap/mapodel';
import { Subject } from 'rxjs';

declare var require:any;
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  @Output() syncToChild:EventEmitter<MapModel> =new EventEmitter<MapModel>();
  synctoMapComponent: Subject<MapModel> = new Subject<MapModel>();
  selectedStateCode = 'US-TN';  
  mapModelObject:MapModel=new MapModel();
  constructor() { }
  ngOnInit() {
    console.log("APP STARTED");
  }


  
  receiveMessage(data:MapModel) {
    this.mapModelObject=data;
  }


  selectState(statecode:string) {
    this.mapModelObject.statecode=statecode;
    this.mapModelObject.districtcode=null;
    this.synctoMapComponent.next(this.mapModelObject);
    //this.syncToChild.emit(this.mapModelObject);

  }

  selectDistrict(districtCode:string) {
   this.mapModelObject.districtcode=districtCode;
   this.synctoMapComponent.next(this.mapModelObject);
  }
}
