import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GpaamapComponent } from './gpaamap.component';

describe('GpaamapComponent', () => {
  let component: GpaamapComponent;
  let fixture: ComponentFixture<GpaamapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GpaamapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GpaamapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
